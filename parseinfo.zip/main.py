#coidng=utf-8

import os

import xml.etree.ElementTree as ET

labelfile=open('label.txt')
labels=labelfile.readlines()



filepath=r'E:\all_data'

os.chdir(filepath)

files=os.listdir(filepath)


for file in files:
    (filename,filetail)=os.path.splitext(file)
    if filename[-4:]=='exif':
        os.rename(file,filename+'.xml')

files=os.listdir(filepath)


for file in files:
    if file.endswith('xml'):
        try:
            writeText=''
            tree=ET.parse(file)
            root=tree.getroot()
            camera='Camera: '
            photoid='Photo ID: '
            photo=root.iter('photo')
            exif=root.iter('exif')

            for p in photo:
                camera=camera+p.get('camera')+'\n'
                photoid=photoid+p.get('id')+'\n'

            writeText=writeText+photoid+camera



            for e in exif:
                for label in labels:
                    if e.get('label')==label.strip():
                        child=e.getchildren()[0]
                        temp = label.strip() + ': ' + child.text + '\n'
                        writeText = writeText + temp
                    print writeText




            # for e in exif:
            #     labellist=e.get('label')
            #     labellist=labellist.split('\n')
            #     for label in labellist:
            #         if e.get('label')==label:
            #             child=e.getchildren()[0]
            #             temp = label + ': ' + child.text + '\n'
            #             writeText=writeText+temp
            #     print writeText


            (filename, filetail) = os.path.splitext(file)
            savename=filename[:-4]+'geo.txt'
            print savename
            f=open(savename,'w')
            f.writelines(writeText)
            f.close()

            camerafile=filename[:-4]+'camera.txt'
            f=open(camerafile,'w')

            f.close()





        except Exception as e:
            print e
        finally:
            print 'done'


